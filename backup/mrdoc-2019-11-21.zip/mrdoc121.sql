#
# TABLE STRUCTURE FOR: bit
#

DROP TABLE IF EXISTS `bit`;

CREATE TABLE `bit` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `bit` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('1234', 'biiii', '1', '1sem');
INSERT INTO `bit` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('EWQ', 'weq', '1', '1sem');
INSERT INTO `bit` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('QWE', 'wqe', '1', '1sem');
INSERT INTO `bit` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('WQ', 'wq', '1', '1sem');


#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `category_data` (`id`, `category`) VALUES (77, 'cs');
INSERT INTO `category_data` (`id`, `category`) VALUES (94, 'dasd');
INSERT INTO `category_data` (`id`, `category`) VALUES (41, 'is');
INSERT INTO `category_data` (`id`, `category`) VALUES (25, 'se');


#
# TABLE STRUCTURE FOR: cs
#

DROP TABLE IF EXISTS `cs`;

CREATE TABLE `cs` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('1', '1', '2', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('1123', '1123', '1', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('213', '12312c', '1', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('CS1109', 'DSA', '1', '2sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('CS1110', 'Computer Systems1', '1', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('CS2101', 'software engineering', '2', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('DSD', 'dsd', '1', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('DSF', 'sdf', '1', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('EW', 'ew', '2', '1sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('GHJ', 'fg', '1', '2sem');
INSERT INTO `cs` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SF', 'dsdd', '1', '1sem');


#
# TABLE STRUCTURE FOR: dasd
#

DROP TABLE IF EXISTS `dasd`;

CREATE TABLE `dasd` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcd
#

DROP TABLE IF EXISTS `dcd`;

CREATE TABLE `dcd` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dn
#

DROP TABLE IF EXISTS `dn`;

CREATE TABLE `dn` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ds
#

DROP TABLE IF EXISTS `ds`;

CREATE TABLE `ds` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dsadad
#

DROP TABLE IF EXISTS `dsadad`;

CREATE TABLE `dsadad` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `dsadad` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('1', '1', '1', '1sem');


#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `external` (`id`, `category`) VALUES (16, 'bit');
INSERT INTO `external` (`id`, `category`) VALUES (71, 'dcd');
INSERT INTO `external` (`id`, `category`) VALUES (0, 'dn');
INSERT INTO `external` (`id`, `category`) VALUES (41, 'ds');


#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('bit1y1sem1234uccse20192020.pdf', '2019-11-15 (11:04:56am)', 'bit', 1, '1sem', '2019/2020', '1234', 'admin', ' undergradute lec (extrnal subject)', 'uccse', 'external');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('bit1y1sem1234ul2asa.pdf', '2019-11-15 (05:38:03pm)', 'bit', 1, '1sem', 'asa', '1234', 'admin', ' asd', 'ul2', 'external');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1sem1123secc12.pdf', '2019-11-15 (05:02:19pm)', 'cs', 1, '1sem', '12', '1123', 'admin', ' 21', 'secc', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1sem1123ul220132016.pdf', '2019-11-15 (05:21:24pm)', 'cs', 1, '1sem', '2013/2016', '1123', 'admin', ' 20', 'ul2', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110dilanka20.pdf', '2019-11-13 (02:54:02pm)', 'cs', 1, '1sem', '20', 'CS1110', 'admin', ' 222', 'dilanka', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110e320152016.pdf', '2019-11-11 (11:11:36am)', 'cs', 1, '1sem', '2015/2016', 'CS1110', 'admin', ' 2', 'e3', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110iscc20122013.pdf', '2019-11-15 (05:27:56pm)', 'cs', 1, '1sem', '2012/2013', 'CS1110', 'admin', ' as', 'iscc', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110pccmsc20.pdf', '2019-11-13 (08:56:13am)', 'cs', 1, '1sem', '20', 'CS1110', 'admin', ' z', 'pccmsc', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110qac222.pdf', '2019-11-13 (09:00:22am)', 'cs', 1, '1sem', '222', 'CS1110', 'admin', ' 22', 'qac', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110qwqqwqw324234.pdf', '2019-11-13 (12:13:09pm)', 'cs', 1, '1sem', '324234', 'CS1110', 'admin', ' 23432', 'qwqqwqw', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110u11212.pdf', '2019-11-13 (02:03:24pm)', 'cs', 1, '1sem', '1212', 'CS1110', 'admin', ' 222', 'u1', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs1y1semCS1110ul120072008.pdf', '2019-11-15 (05:34:08pm)', 'cs', 1, '1sem', '2007/2008', 'CS1110', 'admin', ' ada', 'ul1', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('cs2y1semEWpl120002001.pdf', '2019-11-16 (04:52:19pm)', 'cs', 2, '1sem', '2000/2001', 'EW', 'admin', '212 ', 'pl1', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('is1y1sem123pl220192020.pdf', '2019-11-15 (08:24:51pm)', 'is', 1, '1sem', '2019/2020', '123', 'admin', ' asassa', 'pl2', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('is1y1semIS1111u11.pdf', '2019-11-13 (02:48:16pm)', 'is', 1, '1sem', '1', 'IS1111', 'admin', ' 11111', 'u1', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('mba2y1sem23cscc20122013.pdf', '2019-11-15 (04:51:13pm)', 'mba', 2, '1sem', '2012/2013', '23', 'admin', ' 3', 'cscc', 'post_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('msc1y1semMSC1ph20192020.pdf', '2019-11-15 (07:19:05pm)', 'msc', 1, '1sem', '2019/2020', 'MSC1', 'admin', ' 3', 'ph', 'post_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('msc1y1semMSC1ul14444.pdf', '2019-11-15 (07:19:43pm)', 'msc', 1, '1sem', '4444', 'MSC1', 'admin', ' 3', 'ul1', 'post_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('se1y1sem6666ul120192020.pdf', '2019-11-15 (08:24:06pm)', 'se', 1, '1sem', '2019/2020', '6666', 'admin', ' 11', 'ul1', 'under_graduate');


#
# TABLE STRUCTURE FOR: is
#

DROP TABLE IF EXISTS `is`;

CREATE TABLE `is` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `is` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('123', '123', '1', '1sem');
INSERT INTO `is` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('54', '54', '1', '1sem');
INSERT INTO `is` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('IS1111', 'DSA2', '1', '1sem');


#
# TABLE STRUCTURE FOR: mas
#

DROP TABLE IF EXISTS `mas`;

CREATE TABLE `mas` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `mas` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('2', '1', '2', '1sem');
INSERT INTO `mas` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('32', '32', '4', '2sem');
INSERT INTO `mas` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('MAS1020', 'qqw1q', '1', '1sem');


#
# TABLE STRUCTURE FOR: mba
#

DROP TABLE IF EXISTS `mba`;

CREATE TABLE `mba` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `mba` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('23', '32', '2', '1sem');
INSERT INTO `mba` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('MBA1', 'mba1', '1', '1sem');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (1, 'admin', 'to_all_undergraduate_cs', ' assssssssssssss', '0000-00-00', '00:00:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (2, 'admin', 'to_head_of_institute', ' test', '2019-11-16', '12:42:08');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (3, 'admin', 'to_all', ' test 2', '2019-11-16', '01:15:07');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (4, 'admin', 'to_postgraduate_head', 'aaaaaaaaaaaaaa', '2019-11-16', '13:35:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (5, 'qac', 'to_head_of_institute', 'fffffffffffffff', '2019-11-16', '01:42:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (6, 'qac', 'to_head_of_institute', 'eeeeeeeeeeeeeeeeeee', '2019-11-16', '01:39:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (7, 'qac', 'to_external_head', 'ddddddddddddddddddd', '2019-11-16', '01:49:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (8, 'qac', 'to_qac_head', 'ccccccccccccccccc', '2019-11-16', '01:45:00');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (9, 'admin', 'to_all', ' 0000000000', '2019-11-16', '01:42:26pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (10, 'uccse', 'cs_course_coordinator', ' 12312313', '2019-11-16', '02:58:51pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (11, 'uccse', 'cs_course_coordinator', ' 12313131231313', '2019-11-16', '04:30:40pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (12, 'cscc', 'to_all_undergraduate_cs', '@@@@@@@@@@@@@', '2019-11-16', '04:50:46pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (13, 'eh', 'bit_course_coordinator', ' c11****************', '2019-11-16', '04:57:27pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (14, 'eh', 'to_all_externals', ' aasda', '2019-11-16', '04:58:56pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (15, 'eh', 'bit_course_coordinator', ' 1231', '2019-11-16', '05:00:30pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (16, 'admin', 'to_head_of_institute', ' sda', '2019-11-19', '06:23:21pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (17, 'admin', 'to_head_of_institute', ' adadadadada', '2019-11-20', '08:01:39am');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (18, 'h1', 'to_qac_head', ' test', '2019-11-21', '12:21:17pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (19, 'uccse', 'to_all_undergraduates', ' all underg lec', '2019-11-21', '12:51:11pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (20, 'uccse', 'to_qac', ' qac', '2019-11-21', '12:54:33pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (21, 'uccse', 'se_course_coordinator', ' cc', '2019-11-21', '01:22:14pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (22, 'secc', 'to_undergraduate_head', ' 1111111', '2019-11-21', '01:35:53pm');


#
# TABLE STRUCTURE FOR: mit
#

DROP TABLE IF EXISTS `mit`;

CREATE TABLE `mit` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `mit` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('MIT1', 'mit1', '1', '1sem');


#
# TABLE STRUCTURE FOR: msc
#

DROP TABLE IF EXISTS `msc`;

CREATE TABLE `msc` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `msc` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('MSC1', 'msc1', '1', '1sem');


#
# TABLE STRUCTURE FOR: persons
#

DROP TABLE IF EXISTS `persons`;

CREATE TABLE `persons` (
  `Personid` int(11) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(255) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  PRIMARY KEY (`Personid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `postgraduate` (`id`, `category`) VALUES (12, 'dsadad');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (59, 'mas');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (24, 'mba');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (10, 'mit');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (70, 'msc');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (55, 'sda');


#
# TABLE STRUCTURE FOR: sda
#

DROP TABLE IF EXISTS `sda`;

CREATE TABLE `sda` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: se
#

DROP TABLE IF EXISTS `se`;

CREATE TABLE `se` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `se` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('6666', 'aawe', '1', '1sem');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('123123', '8S1AYFKB', 'under_graduate', 'dilankanimsara101@gmail.com', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('admin', '123', 'qac', 'dilankanimsara101@gmail.com', 'qac_head', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('bitcc', '123', 'external', 'dilankanimsara101@gmail.com', 'course_coordinator', 'bit');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('cscc', '123', 'under_graduate', 'dilankanimsara105@gmail.com', 'head_of_course', ' ');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dilanka', 'DV5lYfOu', 'under_graduate', 'dilankanimsara101@gmail.com', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('e1', '123', 'external', 'dilankanimsara105@gmail.com', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('eh', '133', 'external', '2017is006@stu.ucsc.cmb.ac.lk', 'course_coordinator', 'bit');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('h1', '123', 'head_of_institute', 'dilankanimsara105@gmail.com', 'head_of_institute', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('iscc', '123', 'under_graduate', 'dilankanimsara103@gmail.com', 'course_coordinator', 'dasd');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('mbacc', '1234', 'post_graduate', '2017is006@stu.ucsc.cmb.ac.lk', 'course_coordinator', 'mba');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('ph', '123', 'post_graduate', 'dilankanimsara101@gmail.com', 'lecturer', ' ');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('secc', '123', 'under_graduate', 'dilankanimsara101@gmail.com', 'course_coordinator', 'se');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uccse', '123', 'under_graduate', 'dilankanimsara101@gmail.com', 'head_of_course', ' ');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('ul2', '123', 'qac', 'dilankanimsara103@gmail.com', 'qac', '');


