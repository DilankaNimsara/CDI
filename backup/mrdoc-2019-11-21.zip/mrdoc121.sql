#
# TABLE STRUCTURE FOR: a
#

DROP TABLE IF EXISTS `a`;

CREATE TABLE `a` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: aa
#

DROP TABLE IF EXISTS `aa`;

CREATE TABLE `aa` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: autobackup
#

DROP TABLE IF EXISTS `autobackup`;

CREATE TABLE `autobackup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `autobackup` (`id`, `action`) VALUES (1, 'on');


#
# TABLE STRUCTURE FOR: b
#

DROP TABLE IF EXISTS `b`;

CREATE TABLE `b` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) DEFAULT NULL,
  `backup_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `backup` (`id`, `date`, `backup_name`) VALUES (1, '2019-11-21', 'mrdoc-2019-11-21.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name`) VALUES (2, '2019-11-22', 'mrdoc-2019-11-22.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name`) VALUES (3, '2019-11-23', 'mrdoc-2019-11-22.zip');


#
# TABLE STRUCTURE FOR: c
#

DROP TABLE IF EXISTS `c`;

CREATE TABLE `c` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `category_data` (`id`, `category`) VALUES (1, 'a');
INSERT INTO `category_data` (`id`, `category`) VALUES (2, 'aa');


#
# TABLE STRUCTURE FOR: cc
#

DROP TABLE IF EXISTS `cc`;

CREATE TABLE `cc` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `external` (`id`, `category`) VALUES (1, 'c');
INSERT INTO `external` (`id`, `category`) VALUES (2, 'cc');
INSERT INTO `external` (`id`, `category`) VALUES (3, 'zzz');


#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (1, 'uh', 'to_qac_head', ' aaaa', '2019-11-21', '11:38:36pm');


#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `postgraduate` (`id`, `category`) VALUES (1, 'b');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (2, 'vv');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('admin', '123', 'qac', 'dilankanimsara101@gmail.com', 'qac_head', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('qac', '123', 'qac', 'dilankanimara101@gmail.com', 'qac', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uh', 'ZsteVdd4', 'under_graduate', 'dilankanimsara105@gmail.com', 'head_of_course', '');


#
# TABLE STRUCTURE FOR: vv
#

DROP TABLE IF EXISTS `vv`;

CREATE TABLE `vv` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: zzz
#

DROP TABLE IF EXISTS `zzz`;

CREATE TABLE `zzz` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

