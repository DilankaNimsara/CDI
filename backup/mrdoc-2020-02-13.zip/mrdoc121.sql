#
# TABLE STRUCTURE FOR: autobackup
#

DROP TABLE IF EXISTS `autobackup`;

CREATE TABLE `autobackup` (
  `id` varchar(1) NOT NULL,
  `action` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `autobackup` (`id`, `action`) VALUES ('1', 'true');


#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) DEFAULT NULL,
  `backup_name_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (4, '2020-01-16', 'mrdoc-2020-01-16.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (5, '2020-01-17', 'mrdoc-2020-01-17.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (6, '2020-01-20', 'mrdoc-2020-01-20.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (7, '2020-01-22', 'mrdoc-2020-01-22.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (8, '2020-02-12', 'mrdoc-2020-02-12.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (9, '2020-02-13', 'mrdoc-2020-02-13.zip');


#
# TABLE STRUCTURE FOR: bit
#

DROP TABLE IF EXISTS `bit`;

CREATE TABLE `bit` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `category_data` (`id`, `category`) VALUES (3, 'information_system');
INSERT INTO `category_data` (`id`, `category`) VALUES (4, 'computer_science');
INSERT INTO `category_data` (`id`, `category`) VALUES (5, 'software_engineering');


#
# TABLE STRUCTURE FOR: commentst
#

DROP TABLE IF EXISTS `commentst`;

CREATE TABLE `commentst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) DEFAULT NULL,
  `commit` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (1, 'bitBIT123dilanka21321.pdf', ' 333');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (2, 'bitBIT123dilanka21321.pdf', ' aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (3, 'bitBIT123dilanka21321.pdf', ' aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (4, 'bitBIT123dilanka21321.pdf', ' aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (5, 'bitBIT123dilanka21321.pdf', ' vbbb');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (6, 'bitBIT123dilanka21321.pdf', ' ccc');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (7, 'bitBIT123dilanka21321.pdf', ' ccc');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (8, 'information_system1111dilanka322.pdf', ' ');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (9, 'information_system1111dilanka322.pdf', 'there is an error');
INSERT INTO `commentst` (`id`, `filename`, `commit`) VALUES (10, 'information_system1111dilanka322.pdf', ' sadada');


#
# TABLE STRUCTURE FOR: computer_science
#

DROP TABLE IF EXISTS `computer_science`;

CREATE TABLE `computer_science` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('ENH1201', 'Enhancement I', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('ENH1202', 'Enhancement II', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('ENH2201', 'Enhancement III ', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('ENH3201', 'ndustry Placement/ Industry Project', '3', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1201', 'Data Structures and Algorithms I ', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1202', 'Programming Using C ', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1203', 'Database I', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1204', 'Discrete Mathematics I', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1205', 'Computer Systems', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1206', 'Laboratory I', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1207', 'Software Engineering I', '1', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1208', 'Data Structures and Algorithms II', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1209', 'Object Oriented Programming', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1210', 'Software Engineering II', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1211', 'Mathematical Methods I', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1212', 'Foundation of Computer Science', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1213', 'Probability and Statistics', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS1214', 'Operating Systems I', '1', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2201', 'Data Structures and Algorithms III', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2202', 'Group Project I', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2203', 'Software Engineering III', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2204', 'Functional Programming', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2205', 'Computer Networks I', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2206', 'Mathematical Methods II', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2207', 'Programming Language Concepts', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2208', 'Rapid Application Development', '2', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2209', 'Database II', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2210', 'Discrete Mathematics II', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2211', 'Laboratory II', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2212', 'Automata Theory', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2213', 'Electronics and Physical Computing', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS2214', 'Information System Security', '2', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3201', 'Machine Learning and Neural Computing', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3202', 'Advanced Computer Architecture', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3203', 'Middleware Architecture', '3', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3204', 'Management', '3', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3205', 'Computer Graphics I', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3206', 'Graph Theory', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3207', 'Software Quality Assurance', '3', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3208', 'Software Project Management', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3209', 'Human Computer Interaction', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3210', 'Systems and Network Administration', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3211', 'Compiler Theory', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3212', 'Mobile Application Development', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3213', 'Game Development', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3214', 'Group Project II ', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3215', 'Professional Practice', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS3216', 'Research Methods', '3', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS34214', 'Natural Algorithms', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4201', 'Ethical Issues and Legal Aspects in IT', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4202', 'Cognitive Robotics', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4204', 'Data Analytics', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4205', 'Computer Networks II ', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4206', 'Computer Graphics II', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4207', 'Image Processing and Computer Vision', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4208', 'Theory of Computation', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4209', 'Natural Language Processing', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4210', 'Parallel Computing', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4212', 'Formal methods and Software Verification', '4', '1sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4213', 'Digital Forensics', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4214', 'Natural Algorithms', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4215', 'Computational Biology', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4216', 'Advanced Topics in Mathematics', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4217', 'Embedded Systems', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4219', 'Distributed Systems II', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4220', 'Data Structures and Algorithms IV', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4222', 'Logic Programming', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4224', 'Final Year Project in Computer Science* ', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4225', 'Philosophy of Science', '4', '2sem');
INSERT INTO `computer_science` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4226', 'Intelligent Systems', '3', '2sem');


#
# TABLE STRUCTURE FOR: cyber_security
#

DROP TABLE IF EXISTS `cyber_security`;

CREATE TABLE `cyber_security` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `external` (`id`, `category`) VALUES (2, 'bit');


#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('bitBIT123dilanka21321.pdf', '2020-01-20 (05:50:04pm)', 'bit', 1, '1sem', '21321', 'BIT123', 'dilanka', ' 123', 'dilanka', 'external');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('information_system1111dilanka322.pdf', '2020-01-20 (05:43:04pm)', 'information_system', 1, '1sem', '322', '1111', 'dilanka', ' 32', 'dilanka', 'under_graduate');


#
# TABLE STRUCTURE FOR: information_system
#

DROP TABLE IF EXISTS `information_system`;

CREATE TABLE `information_system` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mba
#

DROP TABLE IF EXISTS `mba`;

CREATE TABLE `mba` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (1, 'sj', 'to_all', ' asad', '2020-01-16', '01:29:19pm');


#
# TABLE STRUCTURE FOR: mis
#

DROP TABLE IF EXISTS `mis`;

CREATE TABLE `mis` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mit
#

DROP TABLE IF EXISTS `mit`;

CREATE TABLE `mit` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ncs_cord
#

DROP TABLE IF EXISTS `ncs_cord`;

CREATE TABLE `ncs_cord` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pin
#

DROP TABLE IF EXISTS `pin`;

CREATE TABLE `pin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) NOT NULL,
  `actiontype` varchar(250) NOT NULL,
  `code` varchar(5) NOT NULL,
  `msg` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `postgraduate` (`id`, `category`) VALUES (2, 'mba');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (3, 'mit');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (4, 'mis');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (5, 'cyber_security');
INSERT INTO `postgraduate` (`id`, `category`) VALUES (6, 'ncs_cord');


#
# TABLE STRUCTURE FOR: software_engineering
#

DROP TABLE IF EXISTS `software_engineering`;

CREATE TABLE `software_engineering` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `software_engineering` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4203', 'Database III', '4', '1sem');
INSERT INTO `software_engineering` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4212', 'Formal methods and Software Verification', '4', '1sem');
INSERT INTO `software_engineering` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4221', 'Software Engineering IV', '4', '2sem');
INSERT INTO `software_engineering` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4223', 'Final Year Project in Software Engineering*', '4', '1sem');
INSERT INTO `software_engineering` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('SCS4225', 'Philosophy of Science', '4', '2sem');


#
# TABLE STRUCTURE FOR: trash
#

DROP TABLE IF EXISTS `trash`;

CREATE TABLE `trash` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `trash` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('mbaIS2103dilanka22.pdf', '2020-01-20 (05:39:31pm)', 'mba', 1, '1sem', '22', 'IS2103', 'dilanka', ' 33', 'dilanka', 'post_graduate');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dilanka', '25d55ad283aa400af464c76d713c07ad', 'qac', 'dilankanimsara103@gmail.com', 'qac_head', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dn', '2bc88355cd39d4464facf7b0bc52bb9e', 'head_of_institute', 'dilankanimsara105@gmail.com', 'head_of_institute', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('la', 'b30444063c88684941a63a5500a448c6', 'under_graduate', 'sds@sfs', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('sj', '21232f297a57a5a743894a0e4a801fc3', 'head_of_institute', 'dilankanimsara105@gmail.com', 'head_of_institute', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uglecture', '698d51a19d8a121ce581499d7b701668', 'under_graduate', 'ad@ada', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uhof', '964fb9b2c7f2a769dd59e29ba8830d32', 'under_graduate', '11@gmail.com', 'head_of_course', '');


