#
# TABLE STRUCTURE FOR: autobackup
#

DROP TABLE IF EXISTS `autobackup`;

CREATE TABLE `autobackup` (
  `id` varchar(1) NOT NULL,
  `action` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `autobackup` (`id`, `action`) VALUES ('1', 'true');


#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) DEFAULT NULL,
  `backup_name_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (4, '2020-01-16', 'mrdoc-2020-01-16.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (5, '2020-01-17', 'mrdoc-2020-01-17.zip');


#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `category_data` (`id`, `category`) VALUES (1, 'information_system');


#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('mbaIS2103uglecture20192020.pdf', '2020-01-17 (05:36:49pm)', 'mba', 1, '1sem', '2019/2020', 'IS2103', 'dilanka', ' a', 'uglecture', 'post_graduate');


#
# TABLE STRUCTURE FOR: information_system
#

DROP TABLE IF EXISTS `information_system`;

CREATE TABLE `information_system` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `information_system` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('1111', 'Web', '1', '1sem');


#
# TABLE STRUCTURE FOR: mba
#

DROP TABLE IF EXISTS `mba`;

CREATE TABLE `mba` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `mba` (`subject_code`, `subject_name`, `year`, `semester`) VALUES ('IS2103', 'Maths', '1', '1sem');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (1, 'sj', 'to_all', ' asad', '2020-01-16', '01:29:19pm');


#
# TABLE STRUCTURE FOR: pin
#

DROP TABLE IF EXISTS `pin`;

CREATE TABLE `pin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) NOT NULL,
  `actiontype` varchar(250) NOT NULL,
  `code` varchar(5) NOT NULL,
  `msg` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `postgraduate` (`id`, `category`) VALUES (1, 'mba');


#
# TABLE STRUCTURE FOR: trash
#

DROP TABLE IF EXISTS `trash`;

CREATE TABLE `trash` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `trash` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('asda', '', '', 0, '', '', '', '', '', '', '');
INSERT INTO `trash` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('mbaIS2103uglecture20192020.pdf', '2020-01-17 (05:36:49pm)', 'mba', 1, '1sem', '2019/2020', 'IS2103', 'dilanka', ' a', 'uglecture', 'post_graduate');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dilanka', '21232f297a57a5a743894a0e4a801fc3', 'qac', 'dilankanimsara103@gmail.com', 'qac_head', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dn', '2bc88355cd39d4464facf7b0bc52bb9e', 'head_of_institute', 'dilankanimsara105@gmail.com', 'head_of_institute', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('sj', '21232f297a57a5a743894a0e4a801fc3', 'head_of_institute', 'dilankanimsara105@gmail.com', 'head_of_institute', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uglecture', '698d51a19d8a121ce581499d7b701668', 'under_graduate', 'ad@ada', 'lecturer', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('uhof', '964fb9b2c7f2a769dd59e29ba8830d32', 'under_graduate', '11@gmail.com', 'head_of_course', '');


